
/* laoyebh-sidebar插件 */

$(function(){
    var top= $('#sidebar').offset().top - parseFloat($('#sidebar').css('marginTop').replace(/auto/,0));
    var fooTop= $('#footer').offset().top - parseFloat($('#footer').css('marginTop').replace(/auto/,0));
    var maxy = fooTop -$('#sidebar').outerHeight();
$(window).scroll(function(evt){
    var y =$(this).scrollTop();
    if(y > top){
    if(y < maxY){
    $('#sidebar').addClass('fixed').removeAttr('style');
    }else{
    $('#sidebar').removeClass('fixed').css({
        position:'absolute',
        top:(maxY - top) + 'px'
    });
    }
    }else{
    $('#sidebar').removeClass('fixed');

    }
});
});
