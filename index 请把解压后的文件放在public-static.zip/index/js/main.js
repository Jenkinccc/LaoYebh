/*
$(function(){
  $(".dropdown-toggle").on("mouseover",function(){
    $(this).dropdown('toggle');
  })
  $(".dropdown-toggle").on("mouseout",function(){
    $(this).dropdown('toggle');
  })
})


$(function () {
    $(".dropdown").mouseover(function(){
        $(this).addClass("open");
    });
    $(".dropdown").mouseleave(function(){
        $(this).removeClass("open");
    })
 })
 */

 
/*
$(function() {
    $(".dropdown-toggle").on("mouseover", function() {
        $(".dropdown-menu").show();
    })
    $(".dropdown-toggle").on("mouseout", function() {
        $(".dropdown-menu").hide();
    })
})*/
/*
  jQuery(document).ready(function () {
      new Swiper('.j-slider-15', {
          onInit: function (el) {
              el.slides.addClass('swiper-slide');
              $(el.container[0]).closest('.wpcom-modules'
                   ).on('click', '.swiper-button-next',
                  function () {
                      el.slideNext();
                  }).on('click', '.swiper-button-prev',
                  function () {
                      el.slidePrev();
                  });
          },
          paginationClickable: true,
          autoplay: _wpcom_js.slide_speed ? _wpcom_js.slide_speed : 5000,
          loop: true,
          effect: 'slide',
          slidesPerView: 4,
          spaceBetween: 15,
          slidesPerGroup: 1,
          slideClass: 'item',
          simulateTouch: false,
          breakpoints: {
              480: {
                  slidesPerView: 2,
                  slidesPerGroup: 1,
                  spaceBetween: 10
              },
              767: {
                  slidesPerView: 2,
                  slidesPerGroup: 1,
                  spaceBetween: 10
              },
              1024: {
                  slidesPerView: 2,
                  slidesPerGroup: 1,
                  spaceBetween: 15
              }
          },
          onSlideChangeEnd: function () {
              jQuery(window).trigger('scroll');
          }
      });
  }) 
*/
//移动端轮播图适应
var carousel = $(".carousel");//获取轮播图
var startX,endX,finalMove;//坐标dingw
var divitation = 60 ;//滑动距离
carousel.on("touchstart",function(event){
  startX = event.originalEvent.touches[0].pageX;//获取位置
});
carousel.on("touchstart",function(event){
  endX = event.originalEvent.touches[0].pageX;//停留
})
carousel.on("touchend",function(event){
  finalMove = Math.abs(startX - endX) - divitation;
  if(finalMove> 0 &&(startX - endX) > 0 ){
    $(this).carousel('next');
  }
  else if (finalMove > 0 && (startX - endX) < 0 ){
    $(this).carousel('prev');
  }
})


//精选栏
  $(function () {
    // var timer = null; 声明一个全局定时器
    var index = 0;
    $(".next").click(function () {
        next();
    });
    $(".prev").click(function () {
        prev();
    })
    function next() {
        index++;
        if (index > 2) {
            $(".pic-list").animate({ left: -(index) * 800 }, 500);
            index = 0;
            $(".pic-list").animate({ left: 0 }, 0); //
        }
        $(".pic-list").animate({ left: -index * 800 }, 500);
        iconHover(index);
    }
    function prev() {
        index--;
        if (index < 0) {
            index = 2;
            $(".pic-list").animate({ left: -(index + 1) * 800 }, 0);
        }
        $(".pic-list").animate({ left: -index * 800 }, 500);
        iconHover(index);
    }
});